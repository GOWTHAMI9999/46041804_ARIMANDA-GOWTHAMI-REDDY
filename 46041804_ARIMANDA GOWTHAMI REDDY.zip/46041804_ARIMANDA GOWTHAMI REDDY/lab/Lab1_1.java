package lab;
import java.util.*;
public class Lab1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number");
int num=sc.nextInt();
int sum=0;
while(num!=0)
{
	int digit=num%10;
	sum=sum+digit*digit*digit;
	num=num/10;
}
System.out.println("Sum of cubes of this number:"+sum);
}
}
