package lab;

import java.util.Scanner;

public class Lab1_6 {
public int display(int n)
{
	int i,j,k;
	i=(n*(n+1)*(2*n+1))/6;
	j=(n*(n+1))/2;
	j=j*j;
	k=j-i;
	return k;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
Lab1_6 obj=new Lab1_6();
int l=obj.display(n);
System.out.println(l);
sc.close();
}
}