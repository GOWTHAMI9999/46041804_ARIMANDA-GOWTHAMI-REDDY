package lab;
import java.util.Scanner;
public class Lab3_2 {

	public String getImage(String string) {
		StringBuilder builder = new StringBuilder(string);
		StringBuilder builder2 = new StringBuilder(string);
		builder.reverse();
		String string2 = builder2.append('|').append(builder).toString();
		return string2;

	}

	public static void main(String[] args) {
		Lab3_2 exercise2 = new Lab3_2();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string- ");
		String string = sc.nextLine();
		String string2 = exercise2.getImage(string);
		System.out.println("The required string is- " + string2);
		sc.close();

	}

}
