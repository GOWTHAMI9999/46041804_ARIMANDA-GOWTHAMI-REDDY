package lab;
import java.util.*;
public class Lab3_1 {

	public static void main(String args[]) {
		int number, sum = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the integers separated by a space each-");
		String string = sc.nextLine();
		StringTokenizer st = new StringTokenizer(string, " ");
		while (st.hasMoreTokens()) {
			String temp = st.nextToken();
			number = Integer.parseInt(temp);
			System.out.println(number);
			sum = sum + number;
		}
		System.out.println("The sum of the integers is= " + sum);
		sc.close();
	}

	}

