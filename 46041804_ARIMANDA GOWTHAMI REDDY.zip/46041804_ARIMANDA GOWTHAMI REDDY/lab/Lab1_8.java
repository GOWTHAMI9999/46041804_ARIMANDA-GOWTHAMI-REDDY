package lab;
import java.util.*;
public class Lab1_8 {
public boolean Num(int n)
{
	int i=1;
	while(true)
	{
		i=i*2;
		if(i==n)
		{
			return true;
		}
		else if(i>n)
		{
			return false;
		}
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
Lab1_8 l=new Lab1_8();
boolean b=l.Num(n);
System.out.println(b);
	}

}
