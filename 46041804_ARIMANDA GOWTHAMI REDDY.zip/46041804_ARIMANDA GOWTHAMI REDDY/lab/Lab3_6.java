package lab;
import java.util.Scanner;
import java.util.Arrays;
public class Lab3_6 {
	public boolean positiveStringCheck(String string) {
		System.out.println(string);
		char ch[] = string.toCharArray();
		Arrays.sort(ch);
		String string2 = String.valueOf(ch);
		if (string.equalsIgnoreCase(string2)) {
		return true;
		} else {
			return false;
		}
	}
	public static void main(String[] args) {
		Lab3_6 obj = new Lab3_6();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string- ");
		String string = sc.nextLine();
		boolean result = obj.positiveStringCheck(string.toUpperCase());
		System.out.println("Is the input string positive?- " + result);
		sc.close();

	}



}
