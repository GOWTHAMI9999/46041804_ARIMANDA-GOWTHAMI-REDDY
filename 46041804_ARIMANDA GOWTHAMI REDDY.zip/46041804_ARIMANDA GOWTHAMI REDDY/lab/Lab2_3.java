package lab;
import java.util.Scanner;
import java.util.Arrays;
public class Lab2_3 {

	public int[] getSorted(int arr[]) {
		int arr2[] = new int[arr.length];
		for (int i = 0; i < arr.length; i++) {
			String string = String.valueOf(arr[i]);
			StringBuilder builder = new StringBuilder(string);
			builder.reverse();
			string = builder.toString();
			arr2[i] = Integer.parseInt(string);
		}

		Arrays.sort(arr2);
		return arr2;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Lab2_3 obj = new Lab2_3();
		System.out.println("Enter the size of the array-");
		int size = sc.nextInt();
		int array[] = new int[size];
		System.out.println("Enter the array- ");
		for (int i = 0; i < size; i++) {
			array[i] = sc.nextInt();

		}
		System.out.println("The reverse sorted array - ");

		for (int i : obj.getSorted(array)) {
			System.out.println(i + " ");

		}
		sc.close();

	}

}
