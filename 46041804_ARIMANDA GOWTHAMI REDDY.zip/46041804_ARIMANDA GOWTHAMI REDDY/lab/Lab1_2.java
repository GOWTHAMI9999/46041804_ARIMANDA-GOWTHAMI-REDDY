package lab;
import java.util.*;
public class Lab1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter traffic signal");
String s=sc.nextLine();
switch(s)
{
case "red":
	System.out.println("Stop");
	break;
case "yellow":
	System.out.println("Ready");
	break;
case "green":
	System.out.println("Go");
	break;
	default:
		System.out.println("Invalid");
}
	}
}

