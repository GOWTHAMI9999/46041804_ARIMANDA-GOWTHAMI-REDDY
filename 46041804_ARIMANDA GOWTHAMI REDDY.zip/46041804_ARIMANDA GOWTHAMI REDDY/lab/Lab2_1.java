package lab;
import java.util.Scanner;
import java.util.Arrays;
public class Lab2_1 {
		public int getSecondSmallest(int arr[]) {
			Arrays.sort(arr);
			int second_smallest=arr[1];
			return second_smallest;
			
		}

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			Lab2_1 obj= new Lab2_1();
			System.out.println("Enter the size of the array-");
			int size=sc.nextInt();
			int array[]= new int[size];
			System.out.println("Enter the array- ");
			for (int i = 0; i<size; i++) {
				array[i]=sc.nextInt();
			}
			int result=obj.getSecondSmallest(array);
			System.out.println("The second smallest element is= "+result);
			sc.close();
		}

	}

