package lab;
import java.util.Scanner;
import java.util.Arrays;
public class Lab2_2 {
public String[] sortStrings(String arr[]) {
		
		Arrays.sort(arr);
		int len=arr.length;
		String arr1[]= new String[len];
		
		if (len%2==0) {
			for (int i = 0; i < (len/2); i++) {
				arr1[i]=arr[i].toUpperCase();
			}
			for (int i = (len/2); i < len; i++) {
				arr1[i]=arr[i].toLowerCase();
			}
		} else {
			for (int i = 0; i <=(len/2)-1; i++) {
				arr1[i]=arr[i].toLowerCase();
			}
			for (int i = (len/2); i < len; i++) {
				arr1[i]=arr[i].toUpperCase();
			}

		}
		
		return arr1;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Lab2_2 obj= new Lab2_2();
		System.out.println("Enter the size of the array-");
		int size=sc.nextInt();
		sc.nextLine();
		String array[]= new String[size];
		System.out.println("Enter the array- ");
		for (int i = 0; i<size; i++) {
			array[i]=sc.nextLine();	
			
		}
		String[] result=obj.sortStrings(array);
		System.out.println("The required string- ");
		for (int i = 0; i < result.length; i++) {
			System.out.println(result[i]);
			
		}
		sc.close();
	}
}
