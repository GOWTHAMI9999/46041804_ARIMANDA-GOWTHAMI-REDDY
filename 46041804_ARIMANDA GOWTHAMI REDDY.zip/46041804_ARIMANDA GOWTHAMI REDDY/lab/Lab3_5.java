package lab;
import java.util.Scanner;
public class Lab3_5 {

public static void main(String[] args) {
		
		int word_count=0,line_count=0,char_count=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string- ");
		String string = sc.nextLine();
		line_count++;
		String string2[]=string.split(" ");
		char_count=string.length();
		for (int i = 0; i < string2.length; i++) {
			word_count++;
		}
		System.out.println("The number of characters are- "+char_count);
		System.out.println("The number of lines are- "+line_count);
		System.out.println("The number of words are- "+word_count);
		
			sc.close();
	

	}

}
