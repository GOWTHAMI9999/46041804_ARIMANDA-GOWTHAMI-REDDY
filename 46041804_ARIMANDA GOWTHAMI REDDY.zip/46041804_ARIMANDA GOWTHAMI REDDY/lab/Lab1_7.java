package lab;
import java.util.*;
public class Lab1_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
while(n!=0)
{
	int s1=n%10;
n=n/10;
int s2=n%10;
if(s1<s2)
{
	System.out.println("number is not an increasing num");
	break;
}	
}
if(n==0)
{
	System.out.println("number is an increasing num");
}
	}

}
