package lab;

public class Lab5_1 {
	static int age;
	
	public static void main(String[] args) {
		int age=14;
		try
		{
			if(age<15)
			{
				throw new Exception("age should be above 15");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
