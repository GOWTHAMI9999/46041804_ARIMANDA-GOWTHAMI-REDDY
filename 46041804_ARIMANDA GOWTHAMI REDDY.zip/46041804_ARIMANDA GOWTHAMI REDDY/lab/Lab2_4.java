package lab;
import java.util.Scanner;
import java.util.Arrays;
public class Lab2_4 {

	static int arrsize = 0;

	public int[] modifyArray(int arr[]) {
		int arrlen = arr.length;
		int j = 0, count = 0;
		for (int i = 0; i < arrlen - 1; i++) {
			if (arr[i] != arr[i + 1]) {
				arr[j++] = arr[i];
			} else {
				count++;
			}

		}
		arr[j++] = arr[arrlen - 1];
		arrsize = arr.length - count;

		return arr;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Lab2_4 obj = new Lab2_4();
		System.out.println("Enter the size of the array-");
		int size = sc.nextInt();
		int array[] = new int[size];
		int array2[] = new int[size];
		System.out.println("Enter the array- ");
		for (int i = 0; i < size; i++) {
			array[i] = sc.nextInt();

		}
		Arrays.sort(array);
		System.out.println("The required array in descending order- ");
		array2 = obj.modifyArray(array);
		for (int i = arrsize - 1; i >= 0; i--) {
			System.out.println(array2[i] + " ");

		}
		sc.close();
	}


	}

