package lab;
import java.util.Scanner;
public class Lab3_3 {
	public String alterString(String string) {
		String string2 = "aeiouAEIOU";
		char[] ch = string.toCharArray();
		for (int i = 0; i < ch.length; i++) {

			if (string2.indexOf(ch[i]) >= 0) {
				continue;
			} else {
				ch[i] += 1;
			}

		}
		String string3 = String.valueOf(ch);
		return string3;
	}

	public static void main(String[] args) {
		Lab3_3 obj = new Lab3_3();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string- ");
		String string = sc.nextLine();
		String string2 = obj.alterString(string);
		System.out.println("The required string is- " + string2);
		sc.close();
}


	}

