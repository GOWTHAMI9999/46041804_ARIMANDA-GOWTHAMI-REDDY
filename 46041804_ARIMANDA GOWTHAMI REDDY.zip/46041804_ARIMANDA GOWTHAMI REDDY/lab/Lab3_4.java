package lab;
import java.util.Scanner;
public class Lab3_4 {

	public int modifyNumber(int number1) {
		String string = String.valueOf(number1);
		char[] cs = string.toCharArray();
		int number2;
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < cs.length - 1; i++) {
			builder.append(Math.abs(cs[i + 1] - cs[i]));
		}
		builder.append(cs[cs.length - 1]);
		String string2 = builder.toString();
		number2 = Integer.parseInt(string2);
		return number2;

	}

	public static void main(String[] args) {
		Lab3_4 obj = new Lab3_4();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number- ");
		int num = sc.nextInt();
		int num2 = obj.modifyNumber(num);
		System.out.println("The required modified number is- " + num2);
		sc.close();

	}

}
