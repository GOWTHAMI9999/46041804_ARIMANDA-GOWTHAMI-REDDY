package lab;
import java.util.Scanner;
public class Lab5_2 {
static String firstName;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String lastName="Gowthami";
try
{
	if(firstName==null || lastName==null)
	{
		throw  new Exception("Name should not be blank");
	}
}
catch(Exception e)
{
	System.out.println(e);
}
	}

}
